#include "stdafx.h"
#include "Component.h"