#pragma once
#include "Component.h"
#define NearRight 1.0f
#define NearTop	  1.0f
#define NearLeftt -1.0f
#define NearBot -1.0f

#define FarrRight  1.5f
#define FarrTop	  1.5f
#define FarrLeftt  -1.5f
#define FarrBot   -1.5f

#define Near -2.0f
#define Farr 2.0f
struct World
{
	int mask[ENTITY_COUNT];
	Position	position[ENTITY_COUNT];
	Rotation	rotation[ENTITY_COUNT];
	Scale		scale[ENTITY_COUNT];
	Animation	animation[ENTITY_COUNT];
	Frustum		input[ENTITY_COUNT];
	Mesh		mesh[ENTITY_COUNT];
	Model		model[ENTITY_COUNT];
	DebugMesh	debug_mesh[ENTITY_COUNT];
	LineMesh	line_mesh[ENTITY_COUNT];

};

struct primalVert
{
	XMFLOAT3 position;
	XMFLOAT4 color;
};

struct simple_mesh
{
	float pos[4];
	float norm[3];
	float uv[2];
	float weights[4];
	int joints[4];
};

struct particle 
{ 
	Position pos; //random but near origin
	Position prev_pos; //origin
	Color color; //random
};



#pragma region Static Frustum 
static primalVert frustumVerts[] =
{
	primalVert{ XMFLOAT3(NearLeftt,	NearTop, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//00 NTL
	primalVert{ XMFLOAT3(NearRight,	NearTop, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//01 NTR
	primalVert{ XMFLOAT3(NearRight, NearBot, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//02 NBR
	primalVert{ XMFLOAT3(NearLeftt, NearBot, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//03 NBL
	primalVert{ XMFLOAT3(FarrLeftt,	FarrBot, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//04 FBL
	primalVert{ XMFLOAT3(FarrLeftt,	FarrTop, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//05 FTL
	primalVert{ XMFLOAT3(NearLeftt,	NearTop, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//06 NTL
	primalVert{ XMFLOAT3(NearRight,	NearTop, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//07 NTR
	primalVert{ XMFLOAT3(FarrRight,	FarrTop, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//08 FTR
	primalVert{ XMFLOAT3(FarrLeftt,	FarrTop, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//09 FTL
	primalVert{ XMFLOAT3(FarrLeftt, FarrBot, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//10 FBL
	primalVert{ XMFLOAT3(FarrRight, FarrBot, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//11 FBR
	primalVert{ XMFLOAT3(NearRight, NearBot, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//12 NBR
	primalVert{ XMFLOAT3(NearLeftt, NearBot, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//13 NBL
	primalVert{ XMFLOAT3(NearLeftt,	NearTop, Near),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//14 NTL
	primalVert{ XMFLOAT3(FarrLeftt,	FarrTop, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//15 FTL
	primalVert{ XMFLOAT3(FarrRight,	FarrTop, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//16 FTR
	primalVert{ XMFLOAT3(FarrRight, FarrBot, Farr),	XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f) },//17 FBR
};

static unsigned int PainInTheFrust_Intdices[] = {
	// Near Face
	0,
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	12,
	13,
	14,
	15,
	16,
	17,
	18,
	19,
	20,
	21,
	22,
	23,
	24,
	25,
	26,
	27,
	28,
	29,
	30,
	31,
	32,
	33,
	34,
	35
};

#pragma endregion


unsigned int createEntity(World *world);

void destroyEntity(World *world, unsigned int entity);

unsigned int createBox(World *world, Position xyz, Rotation rot, Scale sca, Mesh meshd);

unsigned int createDebugTransformLines(World *world, DebugMesh meshd);

unsigned int createDebugGrid(World * world, DebugMesh mesh);

unsigned int createFrustum(World * world, Mesh meshd);

unsigned int createLine(World * world, LineMesh particle_mesh);

unsigned int createMesh(ID3D11Device * dev, World * world, Mesh mesh, Model model);
