#pragma once
#ifndef CES_COMPONENT_H
#define CES_COMPONENT_H

typedef enum
{
	COMPONENT_NONE = 0,
	COMPONENT_POSITION = 1 << 0,
	COMPONENT_ROTATION = 1 << 1,
	COMPONENT_SCALE = 1 << 2,
	COMPONENT_ANIMATION = 1 << 3,
	COMPONENT_FRUSTUM = 1 << 4,
	COMPONENT_MESH = 1 << 5,
	COMPONENT_MODEL = 1 << 6,
	COMPONENT_DEBUGMESH = 1 << 7,
	COMPONENT_LINEMESH = 1 << 8
} Component;

struct keyframe { double time; std::vector<XMMATRIX> joints; };

struct anim_clip { double duration; std::vector<keyframe> frames; std::vector<int> parent_Indicies; };

struct Position
{
	float pX;
	float pY;
	float pZ;
	Position operator + (CONST Position& v) const
	{
		Position p;
		p.pX = pX + v.pX;
		p.pY = pY + v.pY;
		p.pZ = pZ + v.pZ;
		return p;
	};
	Position operator - (CONST Position& v) const
	{
		Position p;
		p.pX = pX - v.pX;
		p.pY = pY - v.pY;
		p.pZ = pZ - v.pZ;
		return p;
	};
	Position operator * (CONST Position& v) const
	{
		Position p;
		p.pX = pX * v.pX;
		p.pY = pY * v.pY;
		p.pZ = pZ * v.pZ;
		return p;
	};
	Position operator * (CONST int& v) const
	{
		Position p;
		p.pX = pX * v;
		p.pY = pY * v;
		p.pZ = pZ * v;
		return p;
	};
} ;

struct Color
{
	float cR;
	float cG;
	float cB;
	float cA;

	Color operator + (CONST Color& v) const
	{
		Color p;
		p.cR = cR + v.cR;
		p.cG = cG + v.cG;
		p.cB = cB + v.cB;
		p.cA = cA + v.cA;
		return p;
	};
	Color operator - (CONST Color& v) const
	{
		Color p;
		p.cR = cR - v.cR;
		p.cG = cG - v.cG;
		p.cB = cB - v.cB;
		p.cA = cA - v.cA;
		return p;
	};

	Color operator * (CONST float& v) const
	{
		Color p;
		p.cR = cR * v;
		p.cG = cG * v;
		p.cB = cB * v;
		p.cA = cA * v;
		return p;
	};


};

typedef struct
{
	float rX;
	float rY;
	float rZ;
} Rotation;

typedef struct
{
	float sX;
	float sY;
	float sZ;
} Scale;

typedef struct
{
	float vX;
	float vY;
	float vZ;
} Velocity;

typedef struct
{
	anim_clip anim;
	std::vector<int> parent_Indices;
} Animation;

typedef struct
{
	ID3D11Buffer *vertexBuffer;
	ID3D11Buffer *indexBuffer;
	int vertexCount;
	int indexCount;
	D3D11_SHADER_RESOURCE_VIEW_DESC ShaderResourceViewDesc;
	ID3D11ShaderResourceView* shaderResourceView;
	ID3D11Resource * texture;
	D3D11_BUFFER_DESC vertexBufferDesc;
	D3D11_BUFFER_DESC indexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData;
	D3D11_SUBRESOURCE_DATA indexData;
	UINT			vertexBufferStride;
	UINT			vertexBufferOffset;
} Frustum;

typedef struct 
{
	float tU;
	float tV;
} Texture;

typedef struct
{
	ID3D11Buffer *vertexBuffer;
	ID3D11Buffer *indexBuffer;
	ID3D11ShaderResourceView* shaderResourceView1;
	ID3D11ShaderResourceView* shaderResourceView2;
	ID3D11ShaderResourceView* shaderResourceView3;
	D3D11_BUFFER_DESC vertexBufferDesc;
	D3D11_BUFFER_DESC indexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData;
	D3D11_SUBRESOURCE_DATA indexData;
	UINT vertexCount;
	UINT indexCount;
	UINT vertexBufferStride;
	UINT vertexBufferOffset;
} Mesh;

typedef struct
{
	ID3D11Buffer *vertexBuffer;
	int vertexCount;
	D3D11_BUFFER_DESC vertexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData;
	UINT			vertexBufferStride;
	UINT			vertexBufferOffset;
} DebugMesh;

typedef struct
{
	ID3D11Buffer *vertexBuffer;
	int vertexCount;
	D3D11_BUFFER_DESC vertexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData;
	UINT			vertexBufferStride;
	UINT			vertexBufferOffset;
	std::vector<int> pIndicies;
} LineMesh;

typedef struct
{
	anim_clip anim;
	const char* binFilePath;
	double ambientColor[3];
	double diffuseColor[3];
	double specularColor[3];
	double emmissiveColor[3];
	//double transparencyFactor;
	double shininess;
	std::vector<XMMATRIX> inverseBindPoseJointMatrices;
	//double reflectionFactor;
} Model;
#endif
