#include "stdafx.h"
#include "System.h"

System::System()
{
}

System::~System()
{
}

void System::InitD3D(HWND hWnd)
{
	// create a struct to hold information about the swap chain
	DXGI_SWAP_CHAIN_DESC scd;

	// clear out the struct for use
	ZeroMemory(&scd, sizeof(DXGI_SWAP_CHAIN_DESC));

	RECT rect;
	GetClientRect(hWnd, &rect);

	// fill the swap chain description struct
	scd.BufferCount = 1;                                    // one back buffer
	scd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;     // use 32-bit color
	scd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;      // how swap chain is to be used
	scd.OutputWindow = hWnd;                                // the window to be used
	scd.SampleDesc.Count = 1;                               // how many multisamples
	scd.Windowed = TRUE;                                    // windowed/full-screen mode
	scd.BufferDesc.Width = rect.right - rect.left;
	scd.BufferDesc.Height = rect.bottom - rect.top;
	scd.BufferDesc.RefreshRate.Numerator = 60;
	scd.BufferDesc.RefreshRate.Denominator = 1;
	unsigned int flag = 0;
#ifdef _DEBUG
	flag = D3D11_CREATE_DEVICE_DEBUG;
#endif // DEBUG
												// create a device, device context and swap chain using the information in the scd struct
	D3D11CreateDeviceAndSwapChain(NULL,
		D3D_DRIVER_TYPE_HARDWARE,
		NULL,
		flag,
		NULL,
		NULL,
		D3D11_SDK_VERSION,
		&scd,
		&swapchain,
		&dev,
		NULL,
		&devcon);


	#pragma region RenderTargetView And Viewport
	D3D11_TEXTURE2D_DESC textDesc;
	ZeroMemory(&textDesc, sizeof(textDesc));

	ID3D11Texture2D *renderTargetText;

	swapchain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&renderTargetText);
	dev->CreateRenderTargetView(renderTargetText, NULL, &rtv);

	float width = 0;
	float height = 0;
	D3D11_TEXTURE2D_DESC textdesc;

	renderTargetText->GetDesc(&textdesc);
	width = (float)textdesc.Width;
	height = (float)textdesc.Height;

	viewport = {
		0,
		0,
		width,
		height,
		0,
		1
	};
#pragma endregion

	D3D11_TEXTURE2D_DESC descDepth;
	descDepth.Width = (UINT)width;
	descDepth.Height = (UINT)height;
	descDepth.MipLevels = 1;
	descDepth.ArraySize = 1;
	descDepth.Format = DXGI_FORMAT_D32_FLOAT;
	descDepth.SampleDesc.Count = 1;
	descDepth.SampleDesc.Quality = 0;
	descDepth.Usage = D3D11_USAGE_DEFAULT;
	descDepth.BindFlags = D3D11_BIND_DEPTH_STENCIL;
	descDepth.CPUAccessFlags = 0;
	descDepth.MiscFlags = 0;

	dev->CreateTexture2D(&descDepth, NULL, &pDepthStencil);


	D3D11_DEPTH_STENCIL_VIEW_DESC descDSV;
	descDSV.Format = DXGI_FORMAT_D32_FLOAT;
	descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
	descDSV.Texture2D.MipSlice = 0;
	descDSV.Flags = 0;
	dev->CreateDepthStencilView(pDepthStencil, NULL, &depthStencilView);

	D3D11_DEPTH_STENCIL_DESC dsDesc;

	// Depth test parameters
	dsDesc.DepthEnable = true;
	dsDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
	dsDesc.DepthFunc = D3D11_COMPARISON_LESS;

	// Stencil test parameters
	dsDesc.StencilEnable = true;
	dsDesc.StencilReadMask = 0xFF;
	dsDesc.StencilWriteMask = 0xFF;

	// Stencil operations if pixel is front-facing
	dsDesc.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
	dsDesc.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_INCR;
	dsDesc.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
	dsDesc.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;

	// Stencil operations if pixel is back-facing
	dsDesc.BackFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
	dsDesc.BackFace.StencilDepthFailOp = D3D11_STENCIL_OP_DECR;
	dsDesc.BackFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
	dsDesc.BackFace.StencilFunc = D3D11_COMPARISON_ALWAYS;

	// Create depth stencil state
	dev->CreateDepthStencilState(&dsDesc, &depthStencilState);


	D3D11_RASTERIZER_DESC RasterizerStateWireframe
	{
		D3D11_FILL_WIREFRAME,
		D3D11_CULL_NONE,
		FALSE,
		0,
		0.0f,
		0.0f,
		TRUE,
		FALSE,
		FALSE,
		FALSE
	};
	D3D11_RASTERIZER_DESC RasterizerStateNotWireframe
	{
		D3D11_FILL_SOLID,
		D3D11_CULL_BACK,
		FALSE,
		0,
		0.0f,
		0.0f,
		TRUE,
		FALSE,
		FALSE,
		FALSE
	};

	dev->CreateRasterizerState(&RasterizerStateWireframe, &pRSWireFrame);
	dev->CreateRasterizerState(&RasterizerStateNotWireframe, &pRSNotWireFrame);
}

void System::CleanD3D(World *planet)
{
	// close and release all existing COM objects
	for (int i = 0; i < ENTITY_COUNT; i++)
	{
		if (planet->mask[i] == (COMPONENT_POSITION | COMPONENT_MESH | COMPONENT_ANIMATION))//Entity is a cube
		{
			planet->mesh[i].indexBuffer->Release();
			planet->mesh[i].vertexBuffer->Release();
		}
		destroyEntity(planet, i);
	}
	swapchain->Release();
	dev->Release();
	devcon->Release();
	depthStencilState->Release();
	depthStencilView->Release();
	rtv->Release();
}

void System::CreateShaders(ID3D11Device * device)
{
	D3D11_BUFFER_DESC matrixBufferDesc;
	D3D11_BUFFER_DESC bpBufferDesc;

	device->CreateVertexShader(MyVertexShader, sizeof(MyVertexShader), NULL, &m_vertexShader);
	device->CreatePixelShader(MyPixelShader, sizeof(MyPixelShader), NULL, &m_pixelShader);
	//Input Layout Setup
	//Now setup the layout of the data that goes into the shader.

	D3D11_INPUT_ELEMENT_DESC m_layoutDesc[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "BLENDWEIGHT", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "BLENDINDICES", 0, DXGI_FORMAT_R32G32B32A32_UINT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	};


	// Get a count of the elements in the layout.
	int	numElements = sizeof(m_layoutDesc) / sizeof(m_layoutDesc[0]);

	// Create the vertex input layout.
	device->CreateInputLayout(m_layoutDesc, numElements, MyVertexShader,
		sizeof(MyVertexShader), &m_layout);

	// Setup the description of the dynamic matrix constant buffer that is in the vertex shader.
	matrixBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	matrixBufferDesc.ByteWidth = sizeof(MatrixBufferType);
	matrixBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	matrixBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	matrixBufferDesc.MiscFlags = 0;
	matrixBufferDesc.StructureByteStride = 0;

	// Create the constant buffer pointer so we can access the vertex shader constant buffer from within this class.
	device->CreateBuffer(&matrixBufferDesc, NULL, &m_matrixBuffer);

	// Setup the description of the dynamic matrix constant buffer that is in the vertex shader.
	bpBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	bpBufferDesc.ByteWidth = sizeof(BlinnPhongType);
	bpBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	bpBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	bpBufferDesc.MiscFlags = 0;
	bpBufferDesc.StructureByteStride = 0;

	// Create the constant buffer pointer so we can access the vertex shader constant buffer from within this class.
	device->CreateBuffer(&bpBufferDesc, NULL, &m_blinnPhong);
}

void System::CreateBuffers(World *planet)//init first frame
{
	CreateShaders(dev);
	for (int i = 0; i < ENTITY_COUNT; i++)
	{
		if (planet->mask[i] == (COMPONENT_LINEMESH))
		{
			if (planet->line_mesh[i].vertexCount)			
				dev->CreateBuffer(&planet->line_mesh[i].vertexBufferDesc, &planet->line_mesh[i].vertexData, &planet->line_mesh[i].vertexBuffer);			
		}
		if (planet->mask[i] == (COMPONENT_DEBUGMESH))
		{
			if (planet->debug_mesh[i].vertexCount)
				dev->CreateBuffer(&planet->debug_mesh[i].vertexBufferDesc, &planet->debug_mesh[i].vertexData, &planet->debug_mesh[i].vertexBuffer);
		}

		if (planet->mask[i] == (COMPONENT_MESH | COMPONENT_MODEL))
		{			
			if (planet->mesh[i].vertexCount)
				dev->CreateBuffer(&planet->mesh[i].vertexBufferDesc, &planet->mesh[i].vertexData, &planet->mesh[i].vertexBuffer);
		}

	}

}

void System::UpdateBuffer(World * wurld, std::vector<simple_mesh> vertVector, int entity, int mask)
{
	bool isVertexBufferSet = false;
		if (isVertexBufferSet)
		{
			// This is where it copies the new vertices to the buffer.
			// but it's causing flickering in the entire screen...
			D3D11_MAPPED_SUBRESOURCE resource;
			if (mask == COMPONENT_LINEMESH)
			{
				devcon->Map(wurld->line_mesh[entity].vertexBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &resource);
				memcpy(resource.pData, &vertVector[0], sizeof(vertVector));
				devcon->Unmap(wurld->line_mesh[entity].vertexBuffer, 0);
			}
			else if (mask == COMPONENT_DEBUGMESH)
			{
				devcon->Map(wurld->debug_mesh[entity].vertexBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &resource);
				memcpy(resource.pData, &vertVector[0], sizeof(vertVector));
				devcon->Unmap(wurld->debug_mesh[entity].vertexBuffer, 0);
			}
		}
		else
		{
			UINT stride = sizeof(simple_mesh);
			UINT offset = 0;

			D3D11_SUBRESOURCE_DATA resourceData;
			ZeroMemory(&resourceData, sizeof(resourceData));
			resourceData.pSysMem = &vertVector[0];
			if (mask == COMPONENT_LINEMESH)
			{
				// This is run in the first frame. But what if new vertices are added to the scene?
				wurld->line_mesh[entity].vertexBufferDesc.ByteWidth = sizeof(simple_mesh) * wurld->line_mesh[entity].vertexCount;

				if (wurld->line_mesh[entity].vertexBuffer)
					wurld->line_mesh[entity].vertexBuffer->Release();
				dev->CreateBuffer(&wurld->line_mesh[entity].vertexBufferDesc, &resourceData, &wurld->line_mesh[entity].vertexBuffer);
				devcon->IASetVertexBuffers(0, 1, &wurld->line_mesh[entity].vertexBuffer, &stride, &offset);
			}
			else if (mask == COMPONENT_DEBUGMESH)
			{
				// This is run in the first frame. But what if new vertices are added to the scene?
				wurld->debug_mesh[entity].vertexBufferDesc.ByteWidth = sizeof(simple_mesh) * wurld->debug_mesh[entity].vertexCount;

				if (wurld->debug_mesh[entity].vertexBuffer)
					wurld->debug_mesh[entity].vertexBuffer->Release();
				dev->CreateBuffer(&wurld->debug_mesh[entity].vertexBufferDesc, &resourceData, &wurld->debug_mesh[entity].vertexBuffer);
				devcon->IASetVertexBuffers(0, 1, &wurld->debug_mesh[entity].vertexBuffer, &stride, &offset);
			}
			isVertexBufferSet = true;
		}
}

void System::InitShaderData(ID3D11DeviceContext * deviceContext, XMMATRIX worldMatrix, XMMATRIX viewMatrix, XMMATRIX projectionMatrix, bool collide, int mask, Model * model, XMFLOAT3 lightPos, XMFLOAT3 camPos, XMFLOAT4X4 *x)
{
	HRESULT result;
	
	D3D11_MAPPED_SUBRESOURCE mappedResource;
	MatrixBufferType* dataPtr;

	D3D11_MAPPED_SUBRESOURCE bpResource;
	BlinnPhongType* bpPtr;

	unsigned int bufferNumber;

	#pragma region MatrixData
	XMMATRIX cView;
	cView = viewMatrix;
	//Transpose the matrices to prepare them for the shader.
	cView = XMMatrixInverse(NULL, cView);
	cView = XMMatrixTranspose(cView);
	projectionMatrix = DirectX::XMMatrixTranspose(projectionMatrix);

	//Map Matrix Constant Buffer
	result = deviceContext->Map(m_matrixBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);

	if (mask == (COMPONENT_MESH | COMPONENT_MODEL))
	{
		// Get a pointer to the data in the constant buffer.
		dataPtr = (MatrixBufferType*)mappedResource.pData;

		// Copy the matrices into the constant buffer.
		dataPtr->world = worldMatrix;
		dataPtr->view = cView;
		dataPtr->projection = projectionMatrix;
		memcpy(dataPtr->joints, x, sizeof(dataPtr->joints));
	}
	else
	{
		// Get a pointer to the data in the constant buffer.
		dataPtr = (MatrixBufferType*)mappedResource.pData;

		// Copy the matrices into the constant buffer.
		dataPtr->world = worldMatrix;
		dataPtr->view = cView;
		dataPtr->projection = projectionMatrix;
	}
	//Unmap Matrix Constant Buffer
	deviceContext->Unmap(m_matrixBuffer, 0);

	// Position of the constant buffer in the vertex shader.
	bufferNumber = 0;

	// Set the constant buffer in the vertex shader with the updated values.
	deviceContext->VSSetConstantBuffers(bufferNumber, 2, &m_matrixBuffer);
	bufferNumber++;
#pragma endregion
	
	if (mask == (COMPONENT_MESH | COMPONENT_MODEL))	
	{
		#pragma region BlinnPhong
	result = deviceContext->Map(m_blinnPhong, 0, D3D11_MAP_WRITE_DISCARD, 0, &bpResource);


	// Get a pointer to the data in the constant buffer.
	bpPtr = (BlinnPhongType*)bpResource.pData;
	bpPtr->LightPosition = lightPos;
	bpPtr->CameraPos = camPos;
	bpPtr->Shininess = model->shininess;

	// Unlock the constant buffer.
	deviceContext->Unmap(m_blinnPhong, 0);

	// Set the constant buffer in the vertex shader with the updated values.
	deviceContext->PSSetConstantBuffers(0, 1, &m_blinnPhong);

#pragma endregion
	}
}

void System::ExecutePipeline(World * wurld, ID3D11DeviceContext *deviceContext, int indexCount, int entity)
{
	// Set the vertex input layout.
	deviceContext->IASetInputLayout(m_layout);

	deviceContext->VSSetShader(m_vertexShader, NULL, 0);
	deviceContext->PSSetShader(m_pixelShader, NULL, 0);

	if (wurld->mask[entity] == COMPONENT_LINEMESH)
		deviceContext->Draw(indexCount, 0);
	if (wurld->mask[entity] == COMPONENT_DEBUGMESH)
		deviceContext->Draw(indexCount, 0);
	if (wurld->mask[entity] == (COMPONENT_MESH | COMPONENT_MODEL))
		deviceContext->Draw(indexCount, 0);
}

double System::getFrameCount(std::chrono::time_point<std::chrono::system_clock> s, std::chrono::time_point<std::chrono::system_clock> e)
{
	std::chrono::duration<double> dT = e - s;
	return dT.count();
}

#pragma region Maths

XMMATRIX System::LookAt(XMVECTOR EyePosition, XMVECTOR EyeDirection, XMVECTOR UpDirection)
{

	XMVECTOR EyeDIr = XMVectorSubtract(EyeDirection, EyePosition);
	assert(!XMVector3Equal(EyeDIr, XMVectorZero()));
	assert(!XMVector3IsInfinite(EyeDIr));
	assert(!XMVector3Equal(UpDirection, XMVectorZero()));
	assert(!XMVector3IsInfinite(UpDirection));

	XMVECTOR R2 = XMVector3Normalize(EyeDIr);

	XMVECTOR R0 = XMVector3Cross(UpDirection, R2);
	R0 = XMVector3Normalize(R0);

	XMVECTOR R1 = XMVector3Cross(R2, R0);

	//Inverse below don't need for general case. Only use for view.
	//XMVECTOR NegEyePosition = XMVectorNegate(EyePosition);

	//XMVECTOR D0 = XMVector3Dot(R0, NegEyePosition);
	//XMVECTOR D1 = XMVector3Dot(R1, NegEyePosition);
	//XMVECTOR D2 = XMVector3Dot(R2, NegEyePosition);

	XMMATRIX M;
	M.r[0] = R0;
	M.r[1] = R1;
	M.r[2] = R2;
	M.r[3] = EyePosition;

	//M = XMMatrixTranspose(M);

	return M;
}

XMMATRIX System::TurnTo(XMMATRIX object, Position cameraPos, Position targetPos, Position cameraUp)
{
	//TurnToGen(XMMATRIX objTransform, Position Target);
	//CameraPos = objTransform translation part
	Position p = targetPos - cameraPos;
	p = normalizePosition(p);
	XMFLOAT4X4 fbf;
	XMStoreFloat4x4(&fbf, object);
	Position vCamX;
	Position vCamY;
	//Position vCamZ;

	vCamX.pX = fbf._11;
	vCamX.pY = fbf._12;
	vCamX.pZ = fbf._13;

	vCamY.pX = fbf._21;
	vCamY.pY = fbf._22;
	vCamY.pZ = fbf._23;

	float fTurnRateX = dotProduct(p, vCamY);
	float fTurnRateY = dotProduct(p, vCamX);
	XMMATRIX rot = 
		XMMatrixRotationRollPitchYaw(-fTurnRateX * .001f, fTurnRateY * .001f, 0);
	XMMATRIX v = XMMatrixMultiply(rot, object);
	

	return v;
}

float System::dotProduct(Position vect_A, Position vect_B)
{

	float product = 0;

	// Loop for calculate cot product
	product += vect_A.pX * vect_B.pX;
	product += vect_A.pY * vect_B.pY;
	product += vect_A.pZ * vect_B.pZ;

	return product;
}

Position System::crossProduct(Position vect_A, Position vect_B)
{
	Position cross_P;
	cross_P.pX = vect_A.pY * vect_B.pZ - vect_A.pZ * vect_B.pY;
	cross_P.pY = vect_A.pZ * vect_B.pX - vect_A.pX * vect_B.pZ;
	cross_P.pZ = vect_A.pX * vect_B.pY - vect_A.pY * vect_B.pX;
	return cross_P;
}

Position System::normalizePosition(Position pos)
{
	Position ans;
	float length = 0;
	length = sqrt(pos.pX * pos.pX + pos.pY * pos.pY + pos.pZ * pos.pZ);
	ans.pX = pos.pX / length;
	ans.pY = pos.pY / length;
	ans.pZ = pos.pZ / length;
	return ans;
}

// Multiply a vector and a matrix
//
// IN:		v		The vector ( left hand side)
//			m		The matrix (right hand side)
//
// RETURN:	v*[m]
XMFLOAT4 System::Vector_Matrix_Multiply(XMFLOAT4 v, XMFLOAT4X4 m)
{
	// TODO LAB 2: Replace with your implementation.
	XMFLOAT4 newv;
	newv.x = v.x * m._11 + v.y * m._21 + v.z * m._31 + v.w * m._41;
	newv.y = v.x * m._12 + v.y * m._22 + v.z * m._32 + v.w * m._42;
	newv.z = v.x * m._13 + v.y * m._23 + v.z * m._33 + v.w * m._43;
	newv.w = v.x * m._14 + v.y * m._24 + v.z * m._34 + v.w * m._44;

	return newv;
}

#pragma endregion

#pragma region Frustum & AABB Stuff
System::plane_t System::calculate_plane(Position a, Position b, Position c)
{
	plane_t tempPlane;
	tempPlane.normal = normalizePosition(crossProduct(b - a, c - b));
	tempPlane.offset = dotProduct(tempPlane.normal, a);
	return tempPlane;
}

void System::calculate_frustum(frustum_t & frustum, std::vector<primalVert> & v, XMFLOAT4X4 camera_transform, 
	float fov, float aspect_ratio, 
	float near_offset, float far_offset)
{
	#pragma region Axis, Center, Color, and Near/Far plane Init
	Color xAxis = { camera_transform._11, camera_transform._12, camera_transform._13, camera_transform._14 };
	Color yAxis = { camera_transform._21, camera_transform._22, camera_transform._23, camera_transform._24 };
	Color zAxis = { camera_transform._31, camera_transform._32, camera_transform._33, camera_transform._34 };
	Color pos = { camera_transform._41, camera_transform._42, camera_transform._43, camera_transform._44 };

	Color nearCenter = (pos + (zAxis * near_offset));
	Color farrCenter =  (pos + (zAxis * far_offset));

	farrCenter.cA = 1;
	nearCenter.cA = 1;

	float hNear =	2 * tan(fov / 2) * near_offset;
	float hFar =	2 * tan(fov / 2) * far_offset;
	float wNear = hNear * aspect_ratio;
	float wFarr = hFar * aspect_ratio;

	Color color = { 1.0f, 1.0f, 1.0f, 1.0f };
	Color normals = { 0.0f, 0.0f, 1.0f, 1.0f };
	Color normals2 = { 0.0f, 1.0f, 0.0f, 1.0f };

#pragma endregion

	//N = Near / F = Far
	//T = Top /  B = Bot
	//L = Left / R = Right

	#pragma region Calculate Verts
	Color FTL = farrCenter + yAxis * (hFar*.5f) - xAxis * (wFarr * .5f);
	Color FTR = farrCenter + yAxis * (hFar*.5f) + xAxis * (wFarr * .5f);
	Color FBL = farrCenter - yAxis * (hFar*.5f) - xAxis * (wFarr * .5f);
	Color FBR = farrCenter - yAxis * (hFar*.5f) + xAxis * (wFarr * .5f);

	Color NTL = nearCenter + yAxis * (hNear*.5f) - xAxis * (wNear * .5f);
	Color NTR = nearCenter + yAxis * (hNear*.5f) + xAxis * (wNear * .5f);
	Color NBL = nearCenter - yAxis * (hNear*.5f) - xAxis * (wNear * .5f);
	Color NBR = nearCenter - yAxis * (hNear*.5f) + xAxis * (wNear * .5f);

#pragma endregion

	/*
	BVH and spatial partintioning are not mutually exclusive
	*/
	#pragma region Calculate Planes

	frustum.data[0] = calculate_plane(//Near
		*(Position *)(&NTL), 
		*(Position *)(&NBL), 
		*(Position *)(&NBR));
	frustum.data[1] = calculate_plane(//Far
		*(Position *)(&FTL),
		*(Position *)(&FTR),
		*(Position *)(&FBR));
	frustum.data[2] = calculate_plane(//Left
		*(Position *)(&FTL),
		*(Position *)(&FBL),
		*(Position *)(&NBL));
	frustum.data[3] = calculate_plane(//Right
		*(Position *)(&FBR),
		*(Position *)(&FTR),
		*(Position *)(&NBR));
	frustum.data[4] = calculate_plane(//Up
		*(Position *)(&FTL),
		*(Position *)(&NTL),
		*(Position *)(&NTR));
	frustum.data[5] = calculate_plane(//Down
		*(Position *)(&FBR),
		*(Position *)(&NBR),
		*(Position *)(&NBL));

#pragma endregion

	#pragma region Frustum Verts Init
	primalVert pFTL;
	pFTL.position = *(XMFLOAT3 *)&FTL;
	pFTL.color = *(XMFLOAT4 *)&color;


	primalVert pFTR;
	pFTR.position = *(XMFLOAT3 *)&FTR;
	pFTR.color = *(XMFLOAT4 *)&color;


	primalVert pFBL;
	pFBL.position = *(XMFLOAT3 *)&FBL;
	pFBL.color = *(XMFLOAT4 *)&color;


	primalVert pFBR;
	pFBR.position = *(XMFLOAT3 *)&FBR;
	pFBR.color = *(XMFLOAT4 *)&color;


	primalVert pNTL;
	pNTL.position = *(XMFLOAT3 *)&NTL;
	pNTL.color = *(XMFLOAT4 *)&color;


	primalVert pNTR;
	pNTR.position = *(XMFLOAT3 *)&NTR;
	pNTR.color = *(XMFLOAT4 *)&color;


	primalVert pNBL;
	pNBL.position = *(XMFLOAT3 *)&NBL;
	pNBL.color = *(XMFLOAT4 *)&color;


	primalVert pNBR;
	pNBR.position = *(XMFLOAT3 *)&NBR;
	pNBR.color = *(XMFLOAT4 *)&color;


#pragma endregion

	#pragma region Frustum Plane Normals Init

	//Near Plane
	primalVert pPlaneZero;
	//62,22,34,4
	Color a = ((NTL + NBL) + (NTR + NBR)) * .25f;
	std::cout << a.cR << ", " << a.cG << ", " << a.cB << ", " << a.cA << "\n";
	//62,22,34,4	
	Position ap;
	ap.pX = a.cR;
	ap.pY = a.cG;
	ap.pZ = a.cB;
	Position b = ap + (frustum.data[0].normal * 1);
	std::cout << b.pX << ", " << b.pY << ", " << b.pZ << "\n";
	pPlaneZero.position = *(XMFLOAT3 *)(&(((NTL + NBL) + (NTR + NBR)) * .25f));
	pPlaneZero.color = *(XMFLOAT4 *)(&normals);
	
	primalVert pPlaneZeroX;
	pPlaneZeroX.position = *(XMFLOAT3 *)(&(*(Position *)(&((NTL + NBL) + (NTR + NBR))) * .25f + (frustum.data[0].normal * 1)));
	pPlaneZeroX.color = *(XMFLOAT4 *)(&normals2);

	//Far Plane
	primalVert pPlaneOne;

	pPlaneOne.position = *(XMFLOAT3 *)(&(((FTL + FBL) + (FTR + FBR)) * .25f));
	pPlaneOne.color = *(XMFLOAT4 *)(&normals);

	primalVert pPlaneOneX;
	pPlaneOneX.position = *(XMFLOAT3 *)(&(*(Position *)(&((FTL + FBL) + (FTR + FBR))) * .25f + (frustum.data[1].normal * 1)));
	pPlaneOneX.color = *(XMFLOAT4 *)(&normals2);

	//Left
	primalVert pPlaneTwo;

	pPlaneTwo.position = *(XMFLOAT3 *)(&(((FTL + FBL) + (NTL + NBL)) * .25f));
	pPlaneTwo.color = *(XMFLOAT4 *)(&normals);

	primalVert pPlaneTwoX;
	pPlaneTwoX.position = *(XMFLOAT3 *)(&(*(Position *)(&((FTL + FBL) + (NTL + NBL))) * .25f + (frustum.data[2].normal * 1)));
	pPlaneTwoX.color = *(XMFLOAT4 *)(&normals2);

	//Right
	primalVert pPlaneThree;

	pPlaneThree.position = *(XMFLOAT3 *)(&(((FTR + FBR) + (NTR + NBR)) * .25f));
	pPlaneThree.color = *(XMFLOAT4 *)(&normals);

	primalVert pPlaneThreeX;
	pPlaneThreeX.position = *(XMFLOAT3 *)(&(*(Position *)(&((FTR + FBR) + (NTR + NBR))) * .25f + (frustum.data[3].normal * 1)));
	pPlaneThreeX.color = *(XMFLOAT4 *)(&normals2);

	//Up
	primalVert pPlaneFour;

	pPlaneFour.position = *(XMFLOAT3 *)(&(((FTR + FTL) + (NTR + NTL)) * .25f));
	pPlaneFour.color = *(XMFLOAT4 *)(&normals);

	primalVert pPlaneFourX;
	pPlaneFourX.position = *(XMFLOAT3 *)(&(*(Position *)(&((FTR + FTL) + (NTR + NTL))) * .25f + (frustum.data[4].normal * 1)));
	pPlaneFourX.color = *(XMFLOAT4 *)(&normals2);

	//Down
	primalVert pPlaneFive;

	pPlaneFive.position = *(XMFLOAT3 *)(&(((FBR + FBL) + (NBR + NBL)) * .25f));
	pPlaneFive.color = *(XMFLOAT4 *)(&normals);

	primalVert pPlaneFiveX;
	pPlaneFiveX.position = *(XMFLOAT3 *)(&(*(Position *)(&((FBR + FBL) + (NBR + NBL))) * .25f + (frustum.data[5].normal * 1)));
	pPlaneFiveX.color = *(XMFLOAT4 *)(&normals2);

#pragma endregion
	
	#pragma region  Vector Init for Frustum Drawing
	
	#pragma region Far Face
	//Far Face
	//FTL -> FTR
	vecPos.push_back(pFTL);
	vecPos.push_back(pFTR);
	
	//FBL -> FBR
	vecPos.push_back(pFBL);
	vecPos.push_back(pFBR);

	//FTL -> FBL
	vecPos.push_back(pFTL);
	vecPos.push_back(pFBL);

	//FTR -> FBR
	vecPos.push_back(pFTR);
	vecPos.push_back(pFBR);

#pragma endregion

	#pragma region Near Face
	//Near Face
	//NTL -> NTR
	vecPos.push_back(pNTL);
	vecPos.push_back(pNTR);
		
	//NBL -> NBR
	vecPos.push_back(pNBL);
	vecPos.push_back(pNBR);
		
	//NTL -> NBL
	vecPos.push_back(pNTL);
	vecPos.push_back(pNBL);
			
	//NTR -> NBR
	vecPos.push_back(pNTR);
	vecPos.push_back(pNBR);

#pragma endregion

	#pragma region Sides
	//Sides

	//FTL -> NTL
	vecPos.push_back(pFTL);
	vecPos.push_back(pNTL);

	//FTR -> NTR
	vecPos.push_back(pFTR);
	vecPos.push_back(pNTR);

	//FBL -> NBL
	vecPos.push_back(pFBL);
	vecPos.push_back(pNBL);

	//FBR -> NBR
	vecPos.push_back(pFBR);
	vecPos.push_back(pNBR);

#pragma endregion

	#pragma region Normals
	vecPos.push_back(pPlaneZero);
	vecPos.push_back(pPlaneZeroX);

	vecPos.push_back(pPlaneOne);
	vecPos.push_back(pPlaneOneX);

	vecPos.push_back(pPlaneTwo);
	vecPos.push_back(pPlaneTwoX);

	vecPos.push_back(pPlaneThree);
	vecPos.push_back(pPlaneThreeX);

	vecPos.push_back(pPlaneFour);
	vecPos.push_back(pPlaneFourX);

	vecPos.push_back(pPlaneFive);
	vecPos.push_back(pPlaneFiveX);
#pragma endregion

	v = vecPos;

#pragma endregion

}

int System::classify_sphere_to_plane(const sphere_t & sphere, const plane_t & plane)
{
	float temp = 0;
	temp = dotProduct(sphere.center, plane.normal) - plane.offset;

	if (temp > sphere.radius)
		return 1;
	else if (temp < -sphere.radius)
		return -1;
	else
		return 0;
}
/*
Compares the aabb to the plane and checks if its in front off,
in back off, on ontop of the plans
*/
int System::classify_aabb_to_plane(const aabb_t & aabb, const plane_t & plane, int planeIndex)
{

	float r = aabb.extents.pX * (float)abs(plane.normal.pX) + aabb.extents.pY * 
		(float)abs(plane.normal.pY) + aabb.extents.pZ * (float)abs(plane.normal.pZ);
	sphere_t tempSphere;
	tempSphere.center = aabb.center;
	tempSphere.radius = r;
	int calc = classify_sphere_to_plane(tempSphere, plane);
	//near, far, left. right, up, down

	switch (calc)
	{
	case -1:
		if (planeIndex == 0)
			std::cout << "Completely behind the near plane\n";
		if (planeIndex == 1)
			std::cout << "Completely behind the far plane\n";
		if (planeIndex == 2)
			std::cout << "Completely behind the left plane\n";
		if (planeIndex == 3)
			std::cout << "Completely behind the right plane\n";
		if (planeIndex == 4)
			std::cout << "Completely behind the top plane\n";
		if (planeIndex == 5)
			std::cout << "Completely behind the bot plane\n";
		return -1;
	case 1:
		if (planeIndex == 0)
			std::cout << "Completely in front of the near plane\n";
		if (planeIndex == 1)
			std::cout << "Completely in front of the far plane\n";
		if (planeIndex == 2)
			std::cout << "Completely in front of the left plane\n";
		if (planeIndex == 3)
			std::cout << "Completely in front of the right plane\n";
		if (planeIndex == 4)
			std::cout << "Completely in front of the top plane\n";
		if (planeIndex == 5)
			std::cout << "Completely in front of the bot plane\n";		
		return 1;
	default:
		if (planeIndex == 0)
			std::cout << "Straddling the near plane\n";
		if (planeIndex == 1)
			std::cout << "Straddling the far plane\n";
		if (planeIndex == 2)
			std::cout << "Straddling the left plane\n";
		if (planeIndex == 3)
			std::cout << "Straddling the right plane\n";
		if (planeIndex == 4)
			std::cout << "Straddling the top plane\n";
		if (planeIndex == 5)
			std::cout << "Straddling the bot plane\n";			
		return 0;
	}
}

bool System::aabb_to_frustum(const aabb_t & aabb, const frustum_t & frustum)
{
	for (int i = 0; i < 6; i++)
	{
		if (classify_aabb_to_plane(aabb, frustum.data[i], i) == -1)
		{
			return false;//in frustum
		}
	}
	return true;//not in frustum
}

#pragma endregion

anim_clip System::readAnimationData()
{
	#pragma region ReadAnimationData
	int animFrameCount = 0;
	int nodeCount = 0;
	double duration = 0;
	std::vector<int> parent_Indices;
	std::vector<XMMATRIX> invBindPosesForJoints;
	std::ifstream matFile("../meshData.txt", std::ios::in | std::ios::binary);
	matFile.read((char*)&duration, sizeof(double));
	matFile.read((char*)&nodeCount, sizeof(int));
	matFile.read((char*)&animFrameCount, sizeof(int));
	anim_clip myAnim;
	char * fileName1, *fileName2, *fileName3;

	int bSize = sizeof(double) + sizeof(int) + sizeof(int) + sizeof(int);
	for (int i = 0; i < animFrameCount; i++)
	{
		keyframe myKey;

		//current frame time offset
		double curTime = 0;
		matFile.read((char*)&curTime, sizeof(double));
		bSize += sizeof(double);
		XMFLOAT4X4 temp;
		for (int h = 0; h < nodeCount; h++)
		{
			for (int j = 0; j < 4; j++)
			{
				for (int k = 0; k < 4; k++)
				{
					//joint matrix data

					matFile.read((char*)&temp(j, k), sizeof(float));
					bSize += sizeof(float);
				}
			}
			myKey.joints.push_back(XMLoadFloat4x4(&temp));
		}
		//myKey.joints = XMLoadFloat4x4(&temp);
		myKey.time = curTime / 1000;
		myAnim.frames.push_back(myKey);
	}
	for (int i = 0; i < nodeCount; i++)
	{
		int j = 0;
		matFile.read((char*)&j, sizeof(int));
		bSize += sizeof(int);
		parent_Indices.push_back(j);
	}
	XMFLOAT4X4 fTemp;
	for (int h = 0; h < nodeCount; h++)
	{
		for (int j = 0; j < 4; j++)
		{
			for (int k = 0; k < 4; k++)
			{
				//joint matrix data				
				matFile.read((char*)&fTemp(j,k), sizeof(float));
				bSize += sizeof(float);
			}
		}

		invBindPosesForJoints.push_back(XMMatrixInverse(NULL, XMLoadFloat4x4(&fTemp)));
	}

	myAnim.duration = duration;

	myAnim.parent_Indicies = parent_Indices;
#pragma endregion

	return myAnim;
}