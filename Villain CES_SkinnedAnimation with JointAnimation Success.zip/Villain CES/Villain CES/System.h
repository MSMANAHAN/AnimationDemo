#pragma once
#include "Entity.h"
#include "Component.h"
#include "MyVertexShader.csh"
#include "MyPixelShader.csh"
#include <vector>
class System
{
public:
	// global declarations
	IDXGISwapChain * swapchain;             // the pointer to the swap chain interface
	ID3D11Device *dev;                     // the pointer to our Direct3D device interface
	ID3D11DeviceContext *devcon;           // the pointer to our Direct3D device context
	D3D11_VIEWPORT viewport;
	ID3D11RenderTargetView *rtv;
	ID3D11DepthStencilState* depthStencilState;
	ID3D11DepthStencilView * depthStencilView;
	ID3D11Texture2D* pDepthStencil;
	ID3D11RasterizerState* pRSWireFrame;
	ID3D11RasterizerState* pRSNotWireFrame;
	std::vector<primalVert> vecPos;


	struct MatrixBufferType
	{
		XMMATRIX world;
		XMMATRIX view;
		XMMATRIX projection;
		XMFLOAT4X4 joints[28];
	};

	struct BlinnPhongType
	{
		XMFLOAT3 LightPosition;
		XMFLOAT3 CameraPos;
		float Shininess;
		int padding;
	};
										   // function prototypes
	System();
	~System();
	void InitD3D(HWND hWnd);     // sets up and initializes Direct3D
	void CleanD3D(World * wurld);         // closes Direct3D and releases memory
	//First Frame
	void CreateBuffers(World * wurld);
	//First Frame
	void CreateShaders(ID3D11Device* device);
	//Every Frame
	void InitShaderData(ID3D11DeviceContext * deviceContext, XMMATRIX worldMatrix, XMMATRIX viewMatrix, XMMATRIX projectionMatrix, bool collide, int mask, Model* model, XMFLOAT3 lightPos, XMFLOAT3 camPos, XMFLOAT4X4 *x);
	//Every Frame
	void ExecutePipeline(World * wurld, ID3D11DeviceContext *deviceContext, int indexCount, int entity);

	double getFrameCount(std::chrono::time_point<std::chrono::system_clock> s, std::chrono::time_point<std::chrono::system_clock> e);

	anim_clip readAnimationData();
	XMMATRIX LookAt(XMVECTOR EyePosition, XMVECTOR EyeDirection, XMVECTOR UpDirection);
	XMMATRIX TurnTo(XMMATRIX view, Position cameraPos, Position targetPos, Position cameraUp);
	XMFLOAT4 Vector_Matrix_Multiply(XMFLOAT4 v, XMFLOAT4X4 m);

	// Function that return
	// dot product of two vector array.
	float dotProduct(Position vect_A, Position vect_B);
	Position crossProduct(Position vect_A, Position vect_B);
	Position normalizePosition(Position pos);
	void UpdateBuffer(World * wurld, std::vector<simple_mesh> vertVector, int entity, int mask);
	struct sphere_t { Position center; float radius; }; //Alterative: using sphere_t = float4;

	struct aabb_t { Position center; Position extents; }; //Alternative: aabb_t { float3 min; float3 max; };

	struct plane_t { Position normal; float offset; };  //Alterative: using plane_t = float4;

	struct frustum_t
	{
		plane_t data[6];
	};

	// Calculates the plane of a triangle from three points.
	plane_t calculate_plane(Position a, Position b, Position c);

	// Calculates a frustum (6 planes) from the input parameters.
	//
	// Calculate the eight corner points of the frustum. 
	// Use your debug renderer to draw the edges.
	// 
	// Calculate the frustum planes.
	// Use your debug renderer to draw the plane normals as line segments.
	void calculate_frustum(frustum_t& frustum, std::vector<primalVert> & v, XMFLOAT4X4 camera_transform, float fov, float aspect_ratio, float near_offset, float far_offset);

	// Calculates which side of a plane the sphere is on.
	//
	// Returns -1 if the sphere is completely behind the plane.
	// Returns 1 if the sphere is completely in front of the plane.
	// Otherwise returns 0 (Sphere overlaps the plane)
	int classify_sphere_to_plane(const sphere_t& sphere, const plane_t& plane);

	// Calculates which side of a plane the aabb is on.
	//
	// Returns -1 if the aabb is completely behind the plane.
	// Returns 1 if the aabb is completely in front of the plane.
	// Otherwise returns 0 (aabb overlaps the plane)
	// MUST BE IMPLEMENTED UsING THE PROJECTED RADIUS TEST
	int classify_aabb_to_plane(const aabb_t& aabb, const plane_t& plane, int planeIndex);

	// Determines if the aabb is inside the frustum.
	//
	// Returns false if the aabb is completely behind any plane.
	// Otherwise returns true.
	bool aabb_to_frustum(const aabb_t& aabb, const frustum_t& frustum);

private:
	//D3D11_SAMPLER_DESC	 m_samplerDesc;
	//ID3D11SamplerState	*m_samplerState;
	ID3D11VertexShader	*m_vertexShader;
	ID3D11PixelShader	*m_pixelShader;
	ID3D11InputLayout	*m_layout;
	ID3D11Buffer		*m_matrixBuffer;
	ID3D11Buffer		*m_blinnPhong;

};

